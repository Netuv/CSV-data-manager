Now, the zip file will contain the CSV file ("qrcode_data.csv") with the list of QR code filenames along with the individual QR code images.
"Edit Sample DATA.csv"
It provides a simple and straightforward interface for users to upload a CSV file and generate VCard QR codes. The inclusion of a CSV file with a list of generated QR codes adds a useful feature for tracking the data associated with each QR code.

New Release v. b.0.0.6.3 This modification concatenates FirstName and LastName with a space to form the FullName.